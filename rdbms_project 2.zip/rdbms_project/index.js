function redirectpage(){
    window.location="http://127.0.0.1/rdbms_project/page1.php";
}
setTimeout("redirectpage()",2500);