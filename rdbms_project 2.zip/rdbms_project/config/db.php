<?php
    $con=mysqli_connect("localhost","root","","datas");
    if(!$con){
        die("connection error");
    }
?>